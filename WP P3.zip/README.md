# Breakdown/ Description
The code is fairly straightfoward.
the function createUniqueWords creates a list of unique words that appear in the all the given text.
The function createInvertedList creates an inverted index of all unique words.
The function evaluate takes a row from the query file and the inverted index to turn query phrases and words into a list of corresponding plays or scenes. depending if the and or or flag is present for the query, the fucntion then compares the correpsonding plays or scenes to build a list of plays or scenes that was specified in the query. 

# Libraries
GZip library- to open the .gz file.
os Lbrary - to make a folder in local directory.
sys library- to get command line arguments.
json library - to read the data from the gzip file into a json object.
csv library - to open the .tsv file
time library - to track the time taken to complete each query.

# Dependencies
none

# Building
built

# Running
run code like this from with P3 file command line:
python src/indexer.py src/shakespeare-scenes.json.gz src/trainQueries.tsv results/
where indexer is your src file, shakespeare-scenes.json.gz is the given plays, trainQueries is the querys and results/ is where the reults from the querys will be saved.